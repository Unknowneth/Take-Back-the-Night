package com.notunanancyowen.client;

import com.notunanancyowen.TakeBackTheNight;
import com.notunanancyowen.entities.HerobrineEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.StuckArrowsFeatureRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class HerobrineEntityRenderer extends MobEntityRenderer<HerobrineEntity, HerobrineEntityModel<HerobrineEntity>> {
    public HerobrineEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new HerobrineEntityModel<>(context.getPart(EntityModelLayers.PLAYER)), 0.5F);
        this.addFeature(new StuckArrowsFeatureRenderer<>(context, this));
        this.addFeature(new HerobrineEyesFeatureRenderer<>(this));
        this.addFeature(new HerobrineRiptideAttackFeatureRenderer<>(this, context.getModelLoader()));
    }
    @Override public Identifier getTexture(HerobrineEntity entity) {
        return Identifier.of(TakeBackTheNight.MOD_ID, "textures/entity/herobrine.png");
    }
    @Override public void render(HerobrineEntity livingEntity, float f, float g, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int i) {
        matrixStack.push();
        livingEntity.tickDelta = g;
        this.model.handSwingProgress = this.getHandSwingProgress(livingEntity, g);
        this.model.riding = livingEntity.hasVehicle();
        this.model.child = livingEntity.isBaby();
        float h = MathHelper.lerpAngleDegrees(g, livingEntity.prevBodyYaw, livingEntity.bodyYaw);
        float j = MathHelper.lerpAngleDegrees(g, livingEntity.prevHeadYaw, livingEntity.headYaw);
        float k = j - h;
        if (livingEntity.hasVehicle() && livingEntity.getVehicle() instanceof LivingEntity livingEntity2) {
            h = MathHelper.lerpAngleDegrees(g, livingEntity2.prevBodyYaw, livingEntity2.bodyYaw);
            k = j - h;
            float l = MathHelper.wrapDegrees(k);
            if (l < -85.0F) {
                l = -85.0F;
            }

            if (l >= 85.0F) {
                l = 85.0F;
            }

            h = j - l;
            if (l * l > 2500.0F) {
                h += l * 0.2F;
            }

            k = j - h;
        }

        float m = MathHelper.lerp(g, livingEntity.prevPitch, livingEntity.getPitch());
        if (shouldFlipUpsideDown(livingEntity)) {
            m *= -1.0F;
            k *= -1.0F;
        }

        if (livingEntity.isInPose(EntityPose.SLEEPING)) {
            Direction direction = livingEntity.getSleepingDirection();
            if (direction != null) {
                float n = livingEntity.getEyeHeight(EntityPose.STANDING) - 0.1F;
                matrixStack.translate(-direction.getOffsetX() * n, 0.0F, -direction.getOffsetZ() * n);
            }
        }

        float lx = this.getAnimationProgress(livingEntity, g);
        this.setupTransforms(livingEntity, matrixStack, lx, h, g);
        matrixStack.scale(-1.0F, -1.0F, 1.0F);
        this.scale(livingEntity, matrixStack, g);
        matrixStack.translate(0.0F, -1.501F, 0.0F);
        float n = 0.0F;
        float o = 0.0F;
        if (!livingEntity.hasVehicle() && livingEntity.isAlive()) {
            n = livingEntity.limbAnimator.getSpeed(g);
            o = livingEntity.limbAnimator.getPos(g);
            if (livingEntity.isBaby()) {
                o *= 3.0F;
            }

            if (n > 1.0F) {
                n = 1.0F;
            }
        }

        this.model.animateModel(livingEntity, o, n, g);
        this.model.setAngles(livingEntity, o, n, lx, k, m);
        MinecraftClient minecraftClient = MinecraftClient.getInstance();
        boolean bl = this.isVisible(livingEntity);
        boolean bl2 = !bl && !livingEntity.isInvisibleTo(minecraftClient.player);
        boolean bl3 = minecraftClient.hasOutline(livingEntity);
        RenderLayer renderLayer = this.getRenderLayer(livingEntity, bl, bl2, bl3);
        if (renderLayer != null) {
            VertexConsumer vertexConsumer = vertexConsumerProvider.getBuffer(renderLayer);
            int p = getOverlay(livingEntity, this.getAnimationCounter(livingEntity, g));
            float tp = livingEntity.getDataTracker().get(HerobrineEntity.TP_TIME);
            if(tp > 0F) tp += g;
            if(tp < 0F) tp = 1F;
            else tp = (float)Math.cos(tp * 0.1F * Math.PI);
            this.model.render(matrixStack, vertexConsumer, MathHelper.lerp(tp, 15728640, i), p, 1.0F, tp, 1.0F, (bl2 ? 0.15F : 1.0F) * (tp * 0.5F + 0.5F));
            float fb = livingEntity.getDataTracker().get(HerobrineEntity.CLAP_TIME);
            if(fb > 0F) {
                fb += g;
                fb = (float)Math.sin(fb / 30F * Math.PI);
                matrixStack.scale(1.25F, 1.25F, 1.25F);
                this.model.render(matrixStack, vertexConsumer, 15728640, getOverlay(livingEntity, Math.max(fb, 0F)), 0F, fb, 0.8F * fb, (bl2 ? 0.15F : 1.0F) * fb);
                matrixStack.scale(0.8F, 0.8F, 0.8F);
            }
            fb = livingEntity.getDataTracker().get(HerobrineEntity.FIREBALL_TIME);
            if(fb > 0F && fb < 60F) {
                fb += g;
                fb = (float)Math.sin(fb / 60F * Math.PI);
                matrixStack.scale(1.25F, 1.25F, 1.25F);
                this.model.render(matrixStack, vertexConsumer, 15728640, getOverlay(livingEntity, Math.max(fb, 0F)), fb, 0.8F * fb, 0F, (bl2 ? 0.15F : 1.0F) * fb);
                matrixStack.scale(0.8F, 0.8F, 0.8F);
            }
            fb = livingEntity.getDataTracker().get(HerobrineEntity.SHULKER_TIME);
            if(fb > 0F && fb < 60F) {
                fb += g;
                fb = (float)Math.sin(fb / 60F * Math.PI);
                matrixStack.scale(1.25F, 1.25F, 1.25F);
                this.model.render(matrixStack, vertexConsumer, 15728640, getOverlay(livingEntity, Math.max(fb, 0F)), fb, 0F, 0.8F * fb, (bl2 ? 0.15F : 1.0F) * fb);
                matrixStack.scale(0.8F, 0.8F, 0.8F);
            }
            fb = livingEntity.getDataTracker().get(HerobrineEntity.BREATH_TIME);
            if(fb > 0F && fb < 60F) {
                fb += g;
                fb = (float)Math.sin(fb / 60F * Math.PI);
                matrixStack.scale(1.25F, 1.25F, 1.25F);
                this.model.render(matrixStack, vertexConsumer, 15728640, getOverlay(livingEntity, Math.max(fb, 0F)), fb, 0F, 0.8F * fb, (bl2 ? 0.15F : 1.0F) * fb);
                matrixStack.scale(0.8F, 0.8F, 0.8F);
            }
            fb = livingEntity.getDataTracker().get(HerobrineEntity.SKULL_TIME);
            if(fb > 0F && fb < 80F) {
                fb += g;
                fb = (float)Math.sin(fb / 80F * Math.PI);
                matrixStack.scale(1.25F, 1.25F, 1.25F);
                this.model.render(matrixStack, vertexConsumer, 15728640, getOverlay(livingEntity, fb), fb, fb, fb, (bl2 ? 0.15F : 1.0F) * fb);
                matrixStack.scale(0.8F, 0.8F, 0.8F);
            }
        }

        if (!livingEntity.isSpectator()) {
            for (FeatureRenderer<HerobrineEntity, HerobrineEntityModel<HerobrineEntity>> featureRenderer : this.features) {
                featureRenderer.render(matrixStack, vertexConsumerProvider, i, livingEntity, o, n, g, lx, k, m);
            }
        }
        if (this.hasLabel(livingEntity)) {
            this.renderLabelIfPresent(livingEntity, livingEntity.getDisplayName(), matrixStack, vertexConsumerProvider, i);
        }
        matrixStack.pop();
        //super.render(livingEntity, f, g, matrixStack, vertexConsumerProvider, i);
    }
    @Override protected float getAnimationCounter(HerobrineEntity entity, float tickDelta) {
        if(entity.getDataTracker().get(HerobrineEntity.EXPLOSION_TIME) > 0 && entity.getDataTracker().get(HerobrineEntity.EXPLOSION_TIME) < 40) return (float)Math.abs(Math.sin(entity.getDataTracker().get(HerobrineEntity.EXPLOSION_TIME) / 6F * Math.PI));
        return super.getAnimationCounter(entity, tickDelta);
    }
}
