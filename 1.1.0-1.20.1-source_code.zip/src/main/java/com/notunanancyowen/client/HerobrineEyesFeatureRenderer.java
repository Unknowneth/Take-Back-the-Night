package com.notunanancyowen.client;

import com.notunanancyowen.TakeBackTheNight;
import com.notunanancyowen.entities.HerobrineEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class HerobrineEyesFeatureRenderer<T extends HerobrineEntity> extends EyesFeatureRenderer<T, HerobrineEntityModel<T>>
{
    private static final RenderLayer SKIN = RenderLayer.getEyes(Identifier.of(TakeBackTheNight.MOD_ID, "textures/entity/herobrine_eyes.png"));

    public HerobrineEyesFeatureRenderer(FeatureRendererContext<T, HerobrineEntityModel<T>> featureRendererContext) {
        super(featureRendererContext);
    }
    @Override
    public RenderLayer getEyesTexture() {
        return SKIN;
    }
}
