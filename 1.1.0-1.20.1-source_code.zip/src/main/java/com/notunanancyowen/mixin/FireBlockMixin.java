package com.notunanancyowen.mixin;

import com.notunanancyowen.TakeBackTheNight;
import com.notunanancyowen.entities.HerobrineEntity;
import net.minecraft.block.AbstractFireBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.TorchBlock;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractFireBlock.class)
public abstract class FireBlockMixin {
    @Inject(method = "onBlockAdded", at = @At("TAIL"))
    private void summonHerobrine(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify, CallbackInfo ci) {
        if(HerobrineEntity.activeHerobrine == -1 && world.getBlockState(pos.down()).isIn(BlockTags.INFINIBURN_NETHER) && world.getBlockState(pos.down(2)).isIn(BlockTags.BEACON_BASE_BLOCKS)) {
            for(int i = -1; i <= 1; i++) for(int j = -1; j <= 1; j++) if(!world.getBlockState(pos.add(i, -2, j)).isIn(BlockTags.BEACON_BASE_BLOCKS)) return;
            if(world.getBlockState(pos.down().east()).getBlock() instanceof TorchBlock && world.getBlockState(pos.down().west()).getBlock() instanceof TorchBlock && world.getBlockState(pos.down().south()).getBlock() instanceof TorchBlock && world.getBlockState(pos.down().north()).getBlock() instanceof TorchBlock) {
                HerobrineEntity herobrine = TakeBackTheNight.HEROBRINE.create(world);
                if(herobrine == null) return;
                herobrine.refreshPositionAndAngles(pos, 0F, 90F);
                world.spawnEntity(herobrine);
            }
        }
    }
}
