package com.notunanancyowen;

import com.notunanancyowen.client.HerobrineEntityRenderer;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TakeBackTheNightClient implements ClientModInitializer {
	public static final String MOD_ID = "take-back-the-night";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitializeClient() {
		net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(TakeBackTheNight.HEROBRINE, HerobrineEntityRenderer::new);
		LOGGER.info("Added Herobrine");
	}
}