package com.notunanancyowen;

import com.notunanancyowen.entities.HerobrineEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TakeBackTheNight implements ModInitializer {
	public static final String MOD_ID = "take-back-the-night";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static final EntityType<HerobrineEntity> HEROBRINE = Registry.register(
			Registries.ENTITY_TYPE,
			Identifier.of(MOD_ID, "herobrine"),
			EntityType.Builder.create(HerobrineEntity::new, SpawnGroup.MONSTER).dimensions(0.6F, 1.8F).build("herobrine")
	);
	@Override
	public void onInitialize() {
		LOGGER.info("Added Herobrine");
		FabricDefaultAttributeRegistry.register(HEROBRINE, HerobrineEntity.createHerobrineAttributes());
	}
}